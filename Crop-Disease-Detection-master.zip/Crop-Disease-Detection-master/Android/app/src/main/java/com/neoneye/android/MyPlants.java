package com.neoneye.android;

import android.graphics.Bitmap;

import java.util.Date;

/**
 * Created by rohitrango on 2/1/18.
 */

public class MyPlants {
    public String path;
    public String category;
    public double prob;
    public Bitmap bitmap;
    public Date date;

    public double lon;
    public double lat;
}
